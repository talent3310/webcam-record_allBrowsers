var api_key = 'key-462ac3a3f0c4aa84606ba58bcc99a35d';
var domain = 'mg.21threads.club';
var mailgun = require('mailgun-js')({apiKey: api_key, domain: domain});
var fs = require('fs');

mailgun.get(`/${domain}/unsubscribes`, function (error, body) {
    console.log("unsubscribes====>", body.items);

});
