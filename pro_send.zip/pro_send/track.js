var csv = require('csv-parser');
var fs = require('fs');
var generate = require('csv-generate');
var csvdata = require('csvdata');
var prompt = require('prompt');

var api_key = 'key-462ac3a3f0c4aa84606ba58bcc99a35d';
var domain = 'mg.21threads.club';
var mailgun = require('mailgun-js')({ apiKey: api_key, domain: domain });

var beginTime = new Date("2017-11-21").toUTCString();
// mailgun.get(`/${domain}/events`, {"begin": beginTime, "ascending": "yes", "limit": 10},  function (error, body) {
//     console.log("body====>", body);
// });

/* 
mailgun.get(`/${domain}/stats/total`, {"event": "accepted", "event": "delivered", "event": "failed",
 "event": "opened", "event": "clicked", "event": "unsubscribed", "duration": '1m'}, function (error, body) {
  if(error) {
    console.log("error===>", error);
  }
    console.log("body===>", body.stats);
});

mailgun.get(`/${domain}/stats/total`, {"event": "accepted", "event": "delivered", "duration": '1m'}, function (error, body) {
  if(error) {
    console.log("error===>", error);
  }
    console.log("body===>", body.stats);
});


 */
function formatDate(date) {
  var d = new Date(date),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear();

  if (month.length < 2) month = '0' + month;
  if (day.length < 2) day = '0' + day;

  return [year, month, day].join('-');
}

prompt.get(['days'], function(err, result) {
  var days = result.days + 'd';

  mailgun.get(`/${domain}/stats/total`, {
    "event": ["accepted", "delivered", "opened", "clicked", "failed", "unsubscribed", "complained"],
    "duration": days
  }, function(error, body) {
    // console.log("body====>", body.stats);
    if (error) {
      console.log("error===>", error);
    }
    var data = [];
    var keys = ['time', 'accepted', 'delivered', 'opened', 'clicked', 'failed', 'unsubscribed', 'complained'];
    for (var i = 0; i < body.stats.length; i++) {
      var temp = {};
      for (var k = 0; k < keys.length; k++) {
        var tKey = keys[k];
        if (tKey == 'time') temp[tKey] = formatDate(body.stats[i].time);
        else if (tKey == 'failed') {
          temp[tKey] = body.stats[i][tKey].permanent.total;
        } else {
          temp[tKey] = body.stats[i][tKey].total;
        }
      }
      data.push(temp);
    }
    console.log('data====> ', data);
    csvdata.write('./result/track.csv', data, { header: 'time,accepted,delivered,opened,clicked,failed,unsubscribed,complained' })
  });
});