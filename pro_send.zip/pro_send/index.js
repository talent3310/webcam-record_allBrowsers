var api_key = 'key-462ac3a3f0c4aa84606ba58bcc99a35d';
var domain = 'mg.21threads.club';
let mailgun = require('mailgun-js')({ apiKey: api_key, domain: domain });
let async = require("async");
var csv = require('csv-parser');
var fs = require('fs');
var csvdata = require('csvdata');


var prompt = require('prompt');

prompt.start();

var csvPath;
var htmlPath;
var members = [];
var emailBody;
let count = 0;
let failedEmails = [];
let successEmails = [];

  console.log('processing.....');
  // csvPath = 'csvFiles/' + result.csvFileName + '.csv';
  // htmlPath = 'htmlTemplates/' + result.htmlFileName + '.html';
  csvPath = 'csvFiles/test.csv';
  htmlPath = 'htmlTemplates/live.html';
  emailBody = fs.readFileSync(htmlPath).toString();
  fs.createReadStream(csvPath) //rath-emails.csv test_1.csv
    .pipe(csv())
    .on('data', function(data) {
      members.push({ email: data['email']});
    })
    .on('end', function() {
      var data = {
        from: '21 Threads VIP <vip@21threads.club>',
        subject: 'Nice To See You Again! 30% OFF Sitewide - Early Black Friday SALE! 🎅',
        html: emailBody,
      };

      let arrays = [], size = 130;
      while (members.length > 0) {
        arrays.push(members.splice(0, size));
      }

      async.forEachSeries(arrays, function(arrays_part, callback_series) {
        async.each(arrays_part, function(member, callback) {
          data.to = member.email;
          mailgun.messages().send(data, function(error, body) {
            count++;
            if (error) {
              console.log(member.email + " -error-------------------???");
              failedEmails.push({email: data.to});
              callback(1, null);
            } else {
              console.log(member.email + ' -success!!!');
              successEmails.push({email: data.to});
              callback(null, 1);
            }
            
          });
        }, function(err, responses) {
          callback_series();
          console.log('---------------------------========== Totally sent to ' + count + ' users =================------------------------');
        });
      });

      
    });

// mailgun.get(`/${domain}/unsubscribes`, function (error, body) {
//     console.log("body", body);

// });

//  var data = {
//   from: 'Excited User <me@samples.mailgun.org>',
//   subject: 'Hello',
//   html: emailBody,
//   to: 'talentcode330@gmail.com'
// };
// mailgun.messages().send(data, function (error, body) {
//    console.log("error======>", error);
// });
// var list = mailgun.lists('t_4@mg.21threads.club');
// list.members().list(function (err, members) {
//   var mailList = [];
//   for(var i = 0; i < members.items.length; i++) {
//   	// if(members.items[i].subscribed) {
//   	// 	mailList.push(members.items[i].address);
//   	// }
//   	data.to = members.items[i].address;
//   	mailgun.messages().send(data, function (error, body) {
//     console.log("error======>", error);
// 	});
//   }

//  //  console.log("mailList==>", mailList);

// mailgun.messages().send(data, function (error, body) {
//    console.log("error======>", error);
// });

// });